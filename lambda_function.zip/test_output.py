import a_scrape_articles

def main():
    article_title_lst, article_date_lst, article_text_lst = a_scrape_articles.main()

    content = ''
    for title, date, text in zip(article_title_lst, article_date_lst,
        article_text_lst):
        # content += title.encode('utf-8
        # content += '\n'.encode('utf-8')
        # content += date.encode('utf-8')
        # content += text.encode('utf-8')
        # article_seperator = '\n' + '-' * 100 + '\n'
        # content += article_seperator.encode('utf-8')
        # content += article_seperator.encode('utf-8')
        # content += article_seperator.encode('utf-8')

        content += title
        content += '\n'
        content += date
        content += text
        article_seperator = '\n' + '-' * 100 + '\n'
        content += article_seperator
        content += article_seperator
        content += article_seperator

    with open('test.txt', 'w+') as f:
        f.write(content)

if __name__ == '__main__':
    main()
